<div class="three-col">
	<div class="col">
		<h4>Check our demos !</h4>
		<p>Modula is one of the best responsive WordPress gallery plugin. But don't just take our word, <a href="#">take a look at our demos</a> to see what you can do with our gallery plugin.</p>
	</div>
	<div class="col">
		<h4>Documentation</h4>
		<p>We try to make our plugins very easy to use but we are not perfect but if you give us another chance please <a href="#">check our documentation</a>.</p>
	</div>
	<div class="col">
		<h4>Support</h4>
		<p>If you can't find a solution for your problem, or you want to ask us a pre sale question or just want to talk to us please <a href="#">contact us now</a>.</p>
	</div>
</div>
