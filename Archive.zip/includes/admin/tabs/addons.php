<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e( 'Modula Addons', 'modula-lite' ) ?></h1>
	<a href="#" id="modula-force-reload" class="page-title-action"><?php _e( 'Reload Addons', 'modula-lite' ) ?></a>
	<p><?php _e( 'Addons extend the functionality of Modula Gallery. You can automatically install an addon from this page if avaible.', 'modula-lite' ) ?></p>
</div>
<div class="modula-addons-error"></div>