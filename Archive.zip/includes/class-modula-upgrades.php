<?php

class Modula_Upgrades {

	// Here will be all actions needed after an update.
	private $upgrades = array();

	private $upgrades_key = 'modula_completed_upgrades';
	private $completed_upgrades = array();
	
	function __construct() {
		$upgrades = array(
			'modula_v2' => array(
				'notice'   => esc_html__( 'Modula needs to upgrade the database, click %shere%s to start the upgrade.', 'modula-lite' ),
				'id'       => 'modula-upgrade-v2',
				'version'  => '2.0.0',
				'compare'  => '<',
				'title'    => esc_html__( 'Modula V2 Upgrade', 'modula-lite' ),
				'callback' => 'modula_upgrade_v2',
			),
		);
		$this->upgrades = apply_filters( 'modula_upgrades', $upgrades );
	}

	/**
	 * Grabs the instance of the upgrades class
	 *
	 * @return Modula_Upgrades
	 */
	public static function get_instance() {
		static $inst;
		if ( ! $inst ) {
			$inst = new Modula_Upgrades();
		}
		return $inst;
	}

	public function initialize_admin() {

		add_action( 'admin_notices', array( $this, 'show_upgrade_notices' ) );
		add_action( 'admin_menu', array( $this, 'add_subpages' ), 10 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

		// Ajax to get all galleries
		add_action( 'wp_ajax_modula-get-old-galleries', array( $this, 'get_old_galleries' ), 20 );
		add_action( 'wp_ajax_modula-upgrade-gallery', array( $this, 'upgrade_gallery' ), 20 );
		add_action( 'wp_ajax_modula-complete-upgrade', array( $this, 'set_upgrade_complete' ), 20 );

	}

	public function check_on_activate() {

		// Check if is a new 2.0.0 install or an old install
		$version = get_option( 'modula_version', array() );
		if ( empty( $version ) ) {
			if ( ! $this->check_upgrade_complete( 'modula_v2' ) && $this->check_old_db() ) {
				$version['upgraded_from'] = '1.3.1';
				$version['current_version'] = MODULA_LITE_VERSION;
			}else{
				$version['upgraded_from'] = MODULA_LITE_VERSION;
				$version['current_version'] = MODULA_LITE_VERSION;
			}
		}else{
			$version['upgraded_from'] = $version['current_version'];
			$version['current_version'] = MODULA_LITE_VERSION;
		}

		update_option( 'modula_version', $version );

	}

	/**
	 * Display Upgrade Notices
	 *
	 * @since 2.0.0
	 * @return void
	*/
	public function show_upgrade_notices() {

		$version = get_option( 'modula_version' );
		foreach ( $this->upgrades as $key => $upgrade ) {
			
			if ( version_compare( $version['upgraded_from'], $upgrade['version'], $upgrade['compare'] ) && ! $this->check_upgrade_complete( $key ) ) {
				printf(
					'<div class="updated"><p>' . esc_html( $upgrade['notice'] ) . '</p></div>',
					'<a href="' . esc_url( admin_url( 'options.php?page=' . $upgrade['id'] ) ) . '">',
					'</a>'
				);
			}

		}

	}

	/**
	 * Create Pages for each upgrades
	 *
	 * @since 2.0.0
	 * @return void
	*/
	public function add_subpages() {
		foreach ( $this->upgrades as $key => $upgrade ) {
			add_submenu_page( null, $upgrade['title'], $upgrade['title'], 'manage_options', $upgrade['id'], array( $this, $upgrade['callback'] ) );
		}
	}



	/* Helper Functions */
	private function check_upgrade_complete( $key ) {
		if ( empty( $this->completed_upgrades ) ) {
			$this->completed_upgrades = get_option( $this->upgrades_key, array() );
		}

		return in_array( $key, $this->completed_upgrades );
	}

	/* Function to check if old db exist */
	private function check_old_db() {

		global $wpdb;
		$table_name = $wpdb->prefix.'modula';
		if( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) {
		    return false;
		} else {
			return true;
		}

	}

	public function admin_scripts( $hook ) {
		if ( 'admin_page_modula-upgrade-v2' == $hook ) {
			wp_enqueue_script( 'modula-upgrade', MODULA_URL . 'assets/js/modula-upgrade.js', array( 'jquery' ), '2.0.0', true );
			$args = array(
				'ajaxurl'                 => admin_url( 'admin-ajax.php' ),
				'get_galleries_nonce'     => wp_create_nonce( 'modula-get-galleries-nonce' ),
				'upgrade_gallery_nonce'   => wp_create_nonce( 'modula-upgrade-gallery-nonce' ),
				'upgrade_complete_nonce' => wp_create_nonce( 'modula-upgrade-complete-nonce' ),
			);
			wp_localize_script( 'modula-upgrade', 'modulaUpgraderHelper', $args );
		}
	}

	/* Pages functions */
	public function modula_upgrade_v2() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Upgrade to Modula V2.0.0', 'modula' ) . '</h1>';
		echo '<p class="about-text">' . esc_html__( 'Since Modula V2.0.0 we changed how we stored data about your galleries so in order to have all the old galleries you need to run this updater.', 'modula' ) . '</p>';
		echo '<p class="about-text"><strong>' . esc_html__( 'Please don\'t close this window.', 'modula' ) . '</strong></p>';

		echo '<div class="modula-upgrader-progress-bar-container" style="display:none;width: 90%;border-radius: 50px;height: 40px;border: 1px solid #e5e5e5;box-shadow: 0 1px 1px rgba(0,0,0,.04);background: #fff;position: relative;text-align: center;line-height: 40px;font-size: 20px;"><div class="modula-upgrader-progress-bar" style="width: 0%;height: 100%;background: #008ec2;border-radius: 50px;position: absolute;left: 0;top: 0;"></div><span style="z-index: 9;position: relative;">0%</span></div>';
		echo '<div class="modula-ajax-output"></div>';
		echo '<a href="#" id="modula-upgrade-v2" class="button button-primary">' . esc_html__( 'Start upgrade' ) . '</a>';
		echo '</div>';
	}

	/* Ajax Calls */
	public function get_old_galleries() {
		// Run a security check first.
		check_admin_referer( 'modula-get-galleries-nonce', 'nonce' );
		global $wpdb;

		$galleries_query = 'SELECT * FROM ' . $wpdb->prefix . 'modula';
		$galleries       = $wpdb->get_results( $galleries_query );
		$galleries_ids   = array();

		foreach ( $galleries as $gallery ) {
			$galleries_ids[] = $gallery->Id;
		}

		echo json_encode( array(
			'status'        => 'succes',
			'galleries_ids' => $galleries_ids,
		) );
		die;
	}

	public function upgrade_gallery() {

		// Run a security check first.
		check_admin_referer( 'modula-upgrade-gallery-nonce', 'nonce' );

		$gallery_ID = absint( $_POST['gallery_id'] );

		// Check if we already have imported this gallery
		$post_args = array(
			'post_type' => 'modula-gallery',
			'post_status' => 'publish',
			'meta_query' => array(
				array(
					'key'     => 'modula-id',
					'value'   => $gallery_ID,
				),
			),
		);

		$post_galleries = new WP_Query( $post_args );

		if ( $post_galleries->post_count > 0 ) {
			echo json_encode( array(
				'status'  => 'succes',
				'message' => sprintf( 'The gallery with ID: %s was already imported', $gallery_ID ),
			) );
			die();
		}

		global $wpdb;
		$galleries_query = 'SELECT * FROM ' . $wpdb->prefix . 'modula WHERE Id=' . $gallery_ID;
		$gallery = $wpdb->get_row( $galleries_query );

		if ( $gallery ) {
			
			$id = $gallery->Id;
			$config = json_decode( $gallery->configuration, true );

			$images_query = "SELECT * FROM {$wpdb->prefix}modula_images WHERE gid={$id}";
			$images = $wpdb->get_results( $images_query, ARRAY_A );

			// Insert the gallery post
			$galery_data = array(
				'post_type' => 'modula-gallery',
				'post_status' => 'publish',
			);

			if ( isset( $config['name'] ) ) {
				$galery_data['post_title'] = $config['name'];
			}

			$gallery_id = wp_insert_post( $galery_data );

			/* Parse gallery settings. The toggles have another values now. */
			$modula_settings = $config;
			foreach ( $toggles as $toggle ) {
				$modula_settings[ $toggle ] = ( 'T' == $modula_settings[ $toggle ] ) ? 1 : 0;
			}

			// In modula 2.0 the hoverEffect it's renamed to effect.
			$modula_settings[ 'effect' ] = $modula_settings['hoverEffect'];
			unset( $modula_settings['hoverEffect'] );

			$modula_settings = wp_parse_args( $modula_settings, $default_gallery_settings );

			add_post_meta( $gallery_id, 'modula-settings', $modula_settings, true );

			// Add images to gallery
			$new_images = array();
			require_once MODULA_PATH . 'includes/admin/class-modula-image.php';

			$img_size = absint( $modula_settings['img_size'] );
			$resizer = new Modula_Image();

			foreach ( $images as $image ) {

				$sizes = $resizer->get_image_size( $image['imageId'], $img_size );
				if ( ! is_wp_error( $sizes ) ) {
					$resizer->resize_image( $sizes['url'], $sizes['width'], $sizes['height'] );
				}

				$new_images[] = array(
					'id'      => $image['imageId'],
					'alt'     => '',
					'title'   => $image['title'],
					'caption' => $image['description'],
					'halign'  => $image['halign'],
					'valign'  => $image['valign'],
					'link'    => $image['link'],
					'target'  => $image['target'],
				);

			}

			add_post_meta( $gallery_id, 'modula-images', $new_images, true );
			add_post_meta( $gallery_id, 'modula-id', $id, true );

			echo json_encode( array(
				'status'  => 'succes',
				'message' => sprintf( __( '%s gallery was imported', 'modula' ), $config['name'] ),
			) );
			die;

		}else{

			echo json_encode( array(
				'status'  => 'succes',
				'message' => sprintf( __( 'The gallery with ID: %s failed to import', 'modula' ), $gallery_ID ),
			) );
			die;

		}

	}

	public function set_upgrade_complete() {

		// Run a security check first.
		check_admin_referer( 'modula-upgrade-complete-nonce', 'nonce' );

		$completed = get_option( $this->upgrades_key, array() );
		$completed['modula_v2'] = true;
		update_option( $this->upgrades_key, $completed );

		echo json_encode( array(
			'status'  => 'succes',
			'message' => sprintf( __( 'All Done!', 'modula' ), $gallery_ID ),
		) );
		die;

	}
}